import sys, os, subprocess, reconcore as RC

###############################

def catchErr(test, err_dict, p, t_file):
	err = open(t_file, "r").read();
	if err != "":
		errors[test] = err;
		RC.printWrite(outfilename, 1, "Failed!");
	else:
		RC.printWrite(outfilename, 1, "OK");
		p += 1;
	return err_dict, p;

###############################

start = RC.getLogTime();


python_cmd = sys.argv[1];


grampath = os.path.dirname(__file__)[:-3];
grampath_script = os.path.join(grampath, "grampa.py");
grampath_s = os.path.join(grampath, "data", "manual_species_tree.tre");
grampath_g = os.path.join(grampath, "data", "manual_gene_trees.txt");
grampa_out = os.path.join(grampath, "tests_out");
outfilename = os.path.join(grampath, "tests_log_" + start + ".txt");
RC.filePrep(outfilename);

tmpfile = "tests_" + start + ".tmp";

RC.printWrite(outfilename, 1, "\nRUNNING GRAMPA TESTS");
RC.printWrite(outfilename, 1, start + "\n");

tests = ["labeltree", "multree", "checknum", "main"]
errors = {};
for t in tests:
	errors[t] = "";
numpass = 0;

RC.printWrite(outfilename, 1, "1: --labeltree test.........");
os.system(python_cmd + " " + grampath_script + " -s " + grampath_s + " -v -1 --labeltree 2> " + tmpfile);
errors, numpass = catchErr("labeltree", errors, numpass, tmpfile);
os.system("rm -rf " + grampa_out);

RC.printWrite(outfilename, 1, "2: --multree test...........");
os.system(python_cmd + " " + grampath_script + " -s " + grampath_s + " -g " + grampath_g + " -o " + grampa_out + " -v -1 --buildmultrees 2> " + tmpfile);
errors, numpass = catchErr("multree", errors, numpass, tmpfile);
os.system("rm -rf " + grampa_out);

RC.printWrite(outfilename, 1, "3: --checknum test..........");
os.system(python_cmd + " " + grampath_script + " -s " + grampath_s + " -g " + grampath_g + " -o " + grampa_out + " -v -1 --checknum 2> " + tmpfile);
errors, numpass = catchErr("checknum", errors, numpass, tmpfile);
os.system("rm -rf " + grampa_out);

RC.printWrite(outfilename, 1, "4: MAIN test................");
os.system(python_cmd + " " + grampath_script + " -s " + grampath_s + " -g " + grampath_g + " -o " + grampa_out + " -v -1 --maps 2> " + tmpfile);
errors, numpass = catchErr("main", errors, numpass, tmpfile);
os.system("rm -rf " + grampa_out);

if numpass == 4:
	RC.printWrite(outfilename, 1, "\nDone! All tests pass!\n");
else:
	RC.printWrite(outfilename, 1, "\n" + str(4 - numpass) + " tests failed!");
	print("Check the " + outfilename + " file for more info!");
	RC.printWrite(outfilename, 1, "\n");
	outfile = open(outfilename, "a");
	for test in tests:
		if errors[test] != "":
			outfile.write(test + " failed with the following error:\n");
			outfile.write(errors[test] + "\n\n");
	outfile.close();

os.system("rm " + tmpfile);